# Tesis en Overleaf

Paquete generado con `tools/preparar_overleaf.py`. Se sube tal cual.

## Como subirlo

1. En el proyecto de Overleaf, menu de la izquierda, boton de subir archivos.
2. Arrastra `Tesis_Overleaf.zip`. Overleaf lo descomprime y conserva las
   carpetas.
3. Si el proyecto ya tenia un `main.tex` de ejemplo, borralo antes para que no
   choque con el de la tesis.
4. Menu, seccion Settings, campo *Main document*: debe decir `main.tex`.
5. Compilador: pdfLaTeX. Bibliografia: Biber. Overleaf lo detecta solo.

## Diferencias respecto al repositorio

El contenido es el mismo, con tres ajustes que solo existen en esta copia:

- El preambulo (`standalone_preamble.tex`) esta fusionado dentro de `main.tex`.
  Overleaf identifica el documento principal buscando `\documentclass`, y en el
  repositorio ese comando vive en el preambulo, no en `main.tex`.
- `referencias.bib` viaja en `back/` dentro del proyecto. En el repositorio esta
  un nivel arriba de la carpeta de capitulos.
- Las figuras fotograficas estan en JPEG a 2200 px de ancho. Las de color plano
  siguen en PNG porque convertirlas las hacia mas pesadas. Se excluyeron las 37
  figuras que ningun capitulo referencia.

Los archivos `*_standalone.tex`, que sirven para compilar capitulos por separado
en local, no se incluyen: dependen del preambulo como archivo aparte.

## Si la compilacion se pasa de tiempo

El documento tarda unos 55 segundos en cuatro pasadas en una maquina local. En
Overleaf el limite de los planes de pago es de 4 minutos, que deberia alcanzar.
Si no alcanza, en Settings se puede desactivar `microtype`, que es de lo mas
costoso, o compilar por capitulos cambiando el *Main document*.
